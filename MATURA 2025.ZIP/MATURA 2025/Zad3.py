import math

t = [x.strip() for x in open('dron.txt')]

#3.1.
print('3.1.')
counter = 0
for odcinek in t:
    A, B = odcinek.split()
    if math.gcd(abs(int(A)),abs(int(B))) > 1:
        counter += 1

print(counter)

#3.2
print('3.2.')
X, Y = 0, 0
counter = 0
punkty = []
for odcinek in t:
    A, B = odcinek.split()
    A, B = int(A), int(B)
    X, Y = X+A, Y+B
    punkty.append((X,Y))
    if X>0 and X<5000 and Y>0 and Y<5000:
        counter += 1
print(counter)

print()
for i in range(0,len(punkty)):
    XA, YA = punkty[i]
    for j in range(i+1,len(punkty)):
        XB, YB = punkty[j]
        for srodek in punkty:
            Xs, Ys = srodek
            if not (XA == XB and YA==YB):
               if Xs==(XA+XB)/2 and Ys==(YA+YB)/2:
                   print('A:',XA,YA)
                   print('B:',XB,YB)
                   print('S:',Xs,Ys)


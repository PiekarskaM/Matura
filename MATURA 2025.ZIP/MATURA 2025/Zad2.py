t = [x.strip() for x in open('symbole.txt')]

#2.1
print('2.1')
for symbol in t:
    if symbol==symbol[::-1]:
        print(symbol,end=', ')
print()

#2.2
print('2.2')

counter = 0
srodki = []
for i in range(1,len(t)-1):
    for j in range(1,len(t[i])-1):
        lewo = False
        srodek = False
        prawo = False
        point = t[i][j]
        if t[i-1][j-1] == point and t[i][j-1] == point and t[i+1][j-1] == point:
            lewo = True
        if t[i-1][j] == point and t[i + 1][j] == point:
            srodek = True
        if t[i-1][j+1] == point and t[i][j+1] == point and t[i+1][j+1] == point:
            prawo = True
        if lewo and srodek and prawo:
            srodki.append(f'{i+1} {j+1}')
            counter += 1
print(counter)
for punkt in srodki:
    print(punkt)

#2.3
print('2.3')
max = 0
max_symbol = ''
for symbol in t:
    s = ''
    for znak in symbol:
        if znak == 'o':
            s += '0'
        elif znak == '+':
            s += '1'
        elif znak == '*':
            s += '2'
    if int(s,3) > max:
        max = int(s,3)
        max_symbol = symbol

print(max,max_symbol)

#2.4
print('2.4')
suma = 0
for symbol in t:
    s = ''
    for znak in symbol:
        if znak == 'o':
            s += '0'
        elif znak == '+':
            s += '1'
        elif znak == '*':
            s += '2'
    suma+=int(s,3)

def zamiana(n):
    s = ['o','+','*']
    wynik = ''
    while n>0:
        wynik =  s[n%3] + wynik
        n = n//3
    return wynik

        

print(suma,zamiana(suma))


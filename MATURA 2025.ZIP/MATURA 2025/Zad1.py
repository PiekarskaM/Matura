def przestaw(n):
    print('wywolanie')
    r = n%100
    a = r//10
    b = r%10
    n = n // 100
    if n>0:
        w = a+10*b + 100*przestaw(n)
    else:
        if a>0:
            w = a+10*b
        else:
            w = b
    return w


def przestaw2(n):
    w = 0
    waga = 1
    while n>0:
        r = n%100
        a = r//10
        b = r%10
        n = n//100
        if a>0:
            w = w+b*10*waga+a*waga
        else:
            w = w+b*waga
        waga*=100
    return w


print(przestaw(316498),przestaw2(316498))
print()
print(przestaw(43657688),przestaw2(43657688))
print()
print(przestaw(154005710),przestaw2(154005710))
print()
print(przestaw(998877665544321),przestaw2(998877665544321))

'''
jak bedzie wygladał klucz?
4pkt za prawidłowe rozwiązanie, w tym: 
 1 pkt- jesli uwzglednil nieparzysta liczbe cyfr; 
 1 pkt - za prawidłowe izolowanie par cyferek, 
 1 pkt - za prawidłowe zakonczenie petli, 
 1 pkt - za prawidłowe budowanie nowej liczby
'''
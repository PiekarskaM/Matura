A = [int(x) for x in open('pi.txt')]

def rosnaco_malejacy6(t):
    if t[0]<t[1] and t[2]>t[3]>t[4]>t[5]:
        return True
    if t[0]<t[1]<t[2] and t[3]>t[4]>t[5]:
        return True
    if t[0]<t[1]<t[2]<t[3] and t[4]>t[5]:
        return True
    return False

odp=0
for p in range(0,len(A)-5):
    t = A[p:p+6]
    if rosnaco_malejacy6(t)==True:
        print(t)
        odp+=1
print(odp)
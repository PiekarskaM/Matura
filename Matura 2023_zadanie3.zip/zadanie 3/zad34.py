A = [int(x) for x in open('pi.txt')]

def rosnaco_malejacy(t):
    i = 0
    while True:
        if i+1>=len(t):
            break
        if t[i]<t[i+1]:
            i+=1
        else:
            break
    if i==0:
        return False
    j = len(t)-1
    while True:
        if j-1<0:
            break
        if t[j-1]>t[j]:
            j-=1
        else:
            break

    if j==len(t)-1:
        return False
    if j-i<=1:
        return True
    else:
        return False

                              


max_len = 0
wynik = []
for p in range(0,len(A)):
    for k in range(p+4,len(A)):
        t = A[p:k]
        if rosnaco_malejacy(t)==True:
            if len(t)>max_len:
                max_len=len(t)
                wynik = [t,p+1]
print(max_len,wynik)

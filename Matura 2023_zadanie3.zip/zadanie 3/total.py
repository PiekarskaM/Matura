n = 10000
total = 0
for p in range(0,n - 4):
    for k in range(p + 4, n):
        total += (k - p + 1)

print(total/(10**9))
